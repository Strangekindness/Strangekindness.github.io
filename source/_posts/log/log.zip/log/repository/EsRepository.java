package com.sx.log.repository;

import com.sx.log.entity.SysOperLog;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.stereotype.Repository;

/**
 * @author sy
 * @desciption 操作es的接口
 * @Created 2022年11月23日  17:27
 *
 * 类似mybatis-plus的用法
 */
@Repository
public interface EsRepository extends ElasticsearchRepository<SysOperLog,String> {

}
