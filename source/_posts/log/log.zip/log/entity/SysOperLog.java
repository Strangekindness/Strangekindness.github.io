package com.sx.log.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.sx.common.MyBaseModel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

/**
 * 操作日志记录表 oper_log
 *
 * @author sunyang
 */
@Data
@EqualsAndHashCode(callSuper = true)
@TableName("sys_oper_log")
@Document(indexName = "sys_oper_log")
public class SysOperLog extends MyBaseModel {
    private static final long serialVersionUID = 1L;

    /**
     * 操作模块
     */
    @Field(type = FieldType.Text)
    private String title;

    /**
     * 业务类型（0=其它,1=查询,2=新增,3=修改,4=删除,5=授权,6=导出,7=导入,8=强退,9=生成代码,10=清空数据）
     */
    @Field(type = FieldType.Integer)
    private Integer businessType;

    /**
     * 请求方法
     */
    @Field(type = FieldType.Text)
    private String method;

    /**
     * 请求方式
     */
    @Field(type = FieldType.Text)
    private String requestMethod;

    /**
     * 操作类别（0其它 1后台用户 2手机端用户）
     */
    @Field(type = FieldType.Integer)
    private Integer operatorType;

    /**
     * 操作人员
     */
    @Field(type = FieldType.Text)
    private String operName;

    /**
     * 部门名称
     */
    @Field(type = FieldType.Text)
    private String deptName;

    /**
     * 请求url
     */
    @Field(type = FieldType.Text)
    private String operUrl;

    /**
     * 操作地址
     */
    @Field(type = FieldType.Text)
    private String operIp;

    /**
     * 请求参数
     */
    @Field(type = FieldType.Text)
    private String operParam;

    /**
     * 返回参数
     */
    @Field(type = FieldType.Text)
    private String jsonResult;

    /**
     * 操作状态（0正常 1异常）
     */
    @Field(type = FieldType.Integer)
    private Integer status;

    /**
     * 错误消息
     */
    @Field(type = FieldType.Text)
    private String errorMsg;
}
