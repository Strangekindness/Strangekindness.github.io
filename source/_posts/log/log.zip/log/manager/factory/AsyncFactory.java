package com.sx.log.manager.factory;

import com.sx.log.repository.EsRepository;
import com.sx.log.entity.SysOperLog;
import com.sx.log.service.SysOperLogService;
import com.sx.log.utils.SpringUtils;

import java.util.TimerTask;

/**
 * 异步工厂（产生任务用）
 *
 * @author sunyang
 */
public class AsyncFactory {

    public static final String LOG_CREATE_ID = "log";

    /**
     * 操作日志记录
     *
     * @param operLog 操作日志信息
     * @return 任务task
     */
    public static TimerTask recordOper(final SysOperLog operLog) {
        return new TimerTask() {
            @Override
            public void run() {
                operLog.insertInit(LOG_CREATE_ID);
                //存入mysql
                SpringUtils.getBean(SysOperLogService.class).save(operLog);
                //存入ES
                SpringUtils.getBean(EsRepository.class).save(operLog);
                //Es查询日志方法
                /*Iterable<SysOperLog> sysOperLogList = SpringUtils.getBean(EsRepository.class).findAll();
                for(SysOperLog sysOperLog:sysOperLogList){
                    System.out.println(sysOperLog);
                }*/
            }
        };
    }
}
