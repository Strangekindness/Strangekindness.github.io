package com.sx.log.enums;

/**
 * 操作人类别
 *
 * @author sunyang
 */
public enum OperatorType {
    /**
     * 其它
     */
    OTHER,

    /**
     * pc用户
     */
    MANAGE,

    /**
     * 手机端用户
     */
    MOBILE
}
