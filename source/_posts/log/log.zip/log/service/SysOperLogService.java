package com.sx.log.service;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.sx.log.entity.SysOperLog;
import com.sx.log.mapper.SysOperLogMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


@Service
@Transactional(rollbackFor = Exception.class)
public class SysOperLogService extends ServiceImpl<SysOperLogMapper, SysOperLog> {


}
